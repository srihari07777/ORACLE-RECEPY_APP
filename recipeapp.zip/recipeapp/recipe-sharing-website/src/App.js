import React, { useState } from 'react';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import RecipeForm from './components/RecipeForm';
import RecipeList from './components/RecipeList';
import './components/RecipeForm.css'; 

const App = () => {
  const [recipes, setRecipes] = useState([]);

  const addRecipe = (recipe) => {
    setRecipes([...recipes, recipe]);
  };

  return (
    <div className="app">
      <Header />
      <div className="body">
        <div className="container">
          <RecipeForm addRecipe={addRecipe} />
          <RecipeList recipes={recipes} />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default App;
