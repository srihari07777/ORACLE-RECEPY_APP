import React, { useState } from 'react';
import './RecipeForm.css';  // Make sure to import the CSS file

const RecipeForm = ({ addRecipe }) => {
  const [title, setTitle] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');
  const [image, setImage] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const newRecipe = {
      title,
      ingredients,
      instructions,
      image,
      comments: [],
      rating: 0,
    };
    addRecipe(newRecipe);
    setTitle('');
    setIngredients('');
    setInstructions('');
    setImage(null);
  };

  const handleImageChange = (e) => {
    setImage(URL.createObjectURL(e.target.files[0]));
  };

  return (
    <div className="glass-container">  {/* Updated to glassmorphic container */}
      <form className="recipe-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Recipe Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="input-gradient"
          required
        />
        <textarea
          placeholder="Ingredients"
          value={ingredients}
          onChange={(e) => setIngredients(e.target.value)}
          className="input-gradient"
          required
        />
        <textarea
          placeholder="Instructions"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          className="input-gradient"
          required
        />
        <input type="file" accept="image/*" onChange={handleImageChange} className="input-gradient" required />
        <button type="submit" className="btn-gradient-1">Add Recipe</button>
      </form>
    </div>
  );
};

export default RecipeForm;
