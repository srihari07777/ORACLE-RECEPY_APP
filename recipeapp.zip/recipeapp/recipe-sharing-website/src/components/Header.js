import React from 'react';

const Header = () => {
  return (
    <header className="header">
      <h1>HELLO ORACLE - Recipe Sharing Website</h1>  <br/>
       
    </header>
  );
};

export default Header;

