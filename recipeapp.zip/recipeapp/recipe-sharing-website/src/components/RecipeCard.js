import React, { useState } from 'react';
import './RecipeForm.css';  // Make sure to import the CSS file

const RecipeCard = ({ recipe }) => {
  const [comments, setComments] = useState(recipe.comments || []);
  const [newComment, setNewComment] = useState('');
  const [rating, setRating] = useState(recipe.rating || 0);

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    setComments([...comments, newComment]);
    setNewComment('');
  };

  const handleRatingChange = (e) => {
    setRating(parseInt(e.target.value, 10));
  };

  return (
    <div className="recipe-card">
      {recipe.image && <img src={recipe.image} alt={recipe.title} />}
      <h2>{recipe.title}</h2>
      <p><strong>Ingredients:</strong> {recipe.ingredients}</p>
      <p><strong>Instructions:</strong> {recipe.instructions}</p>
      <div className="rating">
        <label>Rating:</label>
        <select value={rating} onChange={handleRatingChange} className="input-gradient">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
      </div>
      <div className="comments">
        <h3>Comments:</h3>
        <ul>
          {comments.map((comment, index) => (
            <li key={index}>{comment}</li>
          ))}
        </ul>
        <form onSubmit={handleCommentSubmit}>
          <input
            type="text"
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Add a comment"
            className="input-gradient"
            required
          />
          <button type="submit" className="btn-gradient-1">Add Comment</button>
        </form>
      </div>
    </div>
  );
};

export default RecipeCard;
